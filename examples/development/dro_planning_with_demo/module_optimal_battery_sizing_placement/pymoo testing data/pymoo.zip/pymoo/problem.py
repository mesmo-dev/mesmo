    a_matrix = np.load('a_matrix.npy', allow_pickle=True)
    b_vector = np.load('b_vector.npy', allow_pickle=True)
    c_vector = np.load('c_vector.npy', allow_pickle=True)
    q_matrix = np.load('q_matrix.npy', allow_pickle=True)
    d_vector = np.load('d_vector.npy', allow_pickle=True)

    objs = [
        lambda x:  c_vector @ x + x.T @ (0.5 * q_matrix) @ x + d_vector
    ]

    constr_ieq = [lambda x: a_matrix @ x - b_vector]

    n_var = c_vector.size

    problem = FunctionalProblem(n_var,
                                objs,
                                constr_ieq=constr_ieq,
                                )

    F, CV = problem.evaluate(np.random.rand(2, n_var))
    #
    # algorithm = GA(
    #     pop_size=100,
    #     eliminate_duplicates=True)
    #
    # res = minimize(problem,
    #                algorithm,
    #                seed=1,
    #                verbose=False)
    #
    # print("Best solution found: \nX = %s\nF = %s" % (res.X, res.F))

